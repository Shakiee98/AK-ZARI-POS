A.K ZARI STORE — COUNTER POS

FILES
- index.html        Main POS app
- manifest.webmanifest  iPhone/PWA app manifest
- sw.js             Offline app-shell cache/service worker
- icons/            Home Screen app icons

INSTALL ON IPHONE
1. Upload this entire folder to an HTTPS web host. Do not open index.html directly from Files.
2. Open the hosted address in Safari on iPhone.
3. Tap Share -> Add to Home Screen.
4. Keep the suggested name "AK Counter POS" and tap Add.
5. Launch "AK Counter POS" from the Home Screen.

IMPORTANT
- Keep index.html, manifest.webmanifest, sw.js, and the icons folder at the same relative paths.
- The existing Google Apps Script URL and Google Sheet URL in the POS were preserved.
- The service worker caches the local app shell. Google Fonts, Google Sheets, Apps Script and WhatsApp still require internet access when those services are used.
